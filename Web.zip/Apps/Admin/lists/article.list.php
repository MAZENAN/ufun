<?php

return array(
    'model' => 'Article',
    'search' => array(
        array(
            'name' => 'school_id',
            'label' => '学校id',
            'boxname' => 'school_id',
            'type' => 'text',
            'schtp' => '1',
            'style' => 'width:120px',
            'css' => '',
        ),
    ),
    'usesql' => '0',
    'sql' => '',
    'sqlargs' => NULL,
    'usingfy' => '1',
    'orderby' => 'id desc',
);