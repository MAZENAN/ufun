<?php

class SellCategoryController extends SmcmsController{


}