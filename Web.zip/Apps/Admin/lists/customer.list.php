<?php return array (
  'model' => 'Customer',
  'search' => NULL,
  'usesql' => '0',
  'sql' => '',
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => '',
);