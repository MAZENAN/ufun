<?php

return array(
    'model' => 'GoodsOptions',
    'search' => array(
        array(
            'name' => 'goods_id',
            'label' => '商品id',
            'boxname' => 'goods_id',
            'type' => 'text',
            'schtp' => '0',
            'style' => 'width:120px',
            'css' => '',
        )
    ),
    'usesql' => '0',
    'sql' => '',
    'sqlargs' => NULL,
    'usingfy' => '1',
    'orderby' => 'sort asc',
);