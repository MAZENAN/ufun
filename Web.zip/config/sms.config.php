<?php return array (
  'sms_gwurl' => 'http://sdkhttp.eucp.b2m.cn/sdk/SDKService',
  'sms_user' => '3SDK-EMY-0130-ODRST',
  'sms_pwd' => '079572',
  'sms_key' => 'RKTLQmYkWy',
);