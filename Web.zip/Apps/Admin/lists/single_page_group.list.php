<?php return array (
  'model' => 'SinglePageGroup',
  'search' => NULL,
  'usesql' => '0',
  'sql' => NULL,
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => 'sort asc',
);