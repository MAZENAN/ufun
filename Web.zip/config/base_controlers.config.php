<?php return array (
  'BASE_CONTROLERS' => 
  array (
    'Overseas' => 'CampController',
    'SubCamp' => 'CampController',
    'GlobalCamp' => 'CampController',
  ),
);