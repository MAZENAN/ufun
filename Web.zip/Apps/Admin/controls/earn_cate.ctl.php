<?php

class EarnCateController extends SmcmsController{

//    public function listData($select) {
//        return parent::listData($select);
//    }
}