<?php

//return array(
//	'DB_HOST' => '115.28.232.119',
//	'DB_PORT' => 3306,
//	'DB_NAME' => 'waimai',
//	'DB_USER' => 'root',
//	'DB_PWD' => '1983711',
//	'DB_PREFIX' => 'sl_',
//);
return array(
    'DB_HOST' => '127.0.0.1',
    'DB_PORT' => 3306,
    'DB_NAME' => 'waimai_test',
    'DB_USER' => 'root',
    'DB_PWD' => ' ufun2018..',
    'DB_PREFIX' => 'sl_',
);
