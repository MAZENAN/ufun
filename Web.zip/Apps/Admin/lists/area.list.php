<?php return array (
  'model' => 'Area',
  'search' => 
  array (
    0 => 
    array (
      'name' => 'pid',
      'label' => '所属上级分类',
      'boxname' => 'pid',
      'type' => 'hidden',
      'schtp' => '1',
      'style' => '',
      'css' => '',
    ),
  ),
  'usesql' => '0',
  'sql' => '',
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => '',
);