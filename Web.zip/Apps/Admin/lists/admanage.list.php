<?php

return array(
    'model' => 'Admanage',
    'search' => NULL,
    'usesql' => '0',
    'sql' => '',
    'sqlargs' => NULL,
    'usingfy' => '1',
    'orderby' => 'sort desc',
);
