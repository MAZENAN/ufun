<?php return array (
  'smtphost' => 'smtp.exmail.qq.com',
  'smtpport' => '465',
  'smtpfrom' => '营天下',
  'smtpemail' => 'noreply@51camp.cn',
  'smtpuser' => 'noreply@51camp.cn',
  'smtppwd' => 'Noreply123',
);