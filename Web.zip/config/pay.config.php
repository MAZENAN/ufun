<?php return array (
  'pay_host' => 'http://www.zb198.com',
  'alipay_open' => 0,
  'alipay_partner' => '',
  'alipay_key' => '',
  'alipay_email' => '',
  'tenpay_open' => 0,
  'tenpay_partner' => '1900000113',
  'tenpay_key' => 'e82573dc7e6136ba414f2e2affbe39fa',
);