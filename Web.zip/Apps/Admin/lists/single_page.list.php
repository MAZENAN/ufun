<?php return array (
  'model' => 'SinglePage',
  'search' => NULL,
  'usesql' => '0',
  'sql' => NULL,
  'sqlargs' => NULL,
  'usingfy' => '1',
  'orderby' => 'sort asc',
);