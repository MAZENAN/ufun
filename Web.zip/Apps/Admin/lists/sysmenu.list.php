<?php return array (
  'model' => 'Sysmenu',
  'search' => NULL,
  'usesql' => '0',
  'sql' => NULL,
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => NULL,
);