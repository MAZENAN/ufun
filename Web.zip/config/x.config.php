<?php

return array(
    'v1'  => array('appid' =>'wxa79545c3d59a4ded' , 'secret' =>'270a85bf0c325f290c54c401f710fd0b')//waimai
);