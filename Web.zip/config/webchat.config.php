<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


require_once ROOT_DIR."libs/wxpay/lib/WxPay.Api.php";
require_once ROOT_DIR.'libs/wxpay/lib/WxPay.Notify.php';
require_once ROOT_DIR.'libs/wxpay/WxPay.NativePay.php';
require_once ROOT_DIR.'libs/wxpay/WxPay.JsApiPay.php';

require_once ROOT_DIR.'libs/wxpay/log.php';


return array('TOKEN' => 'UFun',
    'APP_ID' => 'wxa79545c3d59a4ded',
    'APP_SECRET' => '270a85bf0c325f290c54c401f710fd0b',
    'OPENID'=>'yingtianxia-2015');
