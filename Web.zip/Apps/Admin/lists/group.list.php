<?php return array (
  'model' => 'Group',
  'search' => NULL,
  'usesql' => '0',
  'sql' => '',
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => '',
);