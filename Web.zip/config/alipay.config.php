<?php

return array(
    'alipay_open' => 1,
    //合作身份者id，以2088开头的16位纯数字
    'alipay_partner' => '2088911923229514',
    //安全检验码，以数字和字母组成的32位字符
    'alipay_key' => 'tqscup3vcy14g49dpmsyqkjquyoykpah',
    'alipay_email' => 'zhifubao@51camp.cn',
);
