<?php return array (
  'model' => 'Wxmenu',
  'search' => NULL,
  'usesql' => '0',
  'sql' => NULL,
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => NULL,
);