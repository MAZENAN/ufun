<?php return array (
  'model' => 'Node',
  'search' => NULL,
  'usesql' => '0',
  'sql' => '',
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => '',
);