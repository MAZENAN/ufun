<?php return array (
  'model' => 'MbCodeLog',
  'search' => NULL,
  'usesql' => '0',
  'sql' => '',
  'sqlargs' => NULL,
  'usingfy' => '1',
  'orderby' => 'id desc',
);