<?php return array (
  'model' => 'Movepics',
  'search' => array(
      array(
          'name' => 'school_id',
          'label' => '学校id',
          'boxname' => 'school_id',
          'type' => 'text',
          'schtp' => '1',
          'style' => 'width:120px',
          'css' => '',
      ),
  ),
  'usesql' => '0',
  'sql' => NULL,
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => 'sort asc',
);