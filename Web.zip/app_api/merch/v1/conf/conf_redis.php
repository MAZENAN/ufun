<?php
global $redis_host ;
global $redis_port;
global $redis_timeout;

$redis_host = "192.168.1.42" ;
//$redis_host = "192.168.0.108" ;
$redis_port = 6379 ;//msq
$redis_timeout = 1 ;
?>

