<?php return array( 
       'basehost' => $_SERVER['SERVER_NAME'],
       'webname' => '营天下',
       'AdminNoPage'=>false,
);