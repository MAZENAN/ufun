<?php

class TagIndexController extends SmcmsController{

//    public function listData($select) {
//        return parent::listData($select);
//    }
}