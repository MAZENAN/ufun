<?php

return array(
    'model' => 'Seller',
    'search' => NULL,
    'usesql' => '0',
    'sql' => '',
    'sqlargs' => NULL,
    'usingfy' => '1',
    'orderby' => 'id desc',
);