<?php

return array(
    'model' => 'Delivery',
    'search' => NULL,
    'usesql' => '0',
    'sql' => '',
    'sqlargs' => NULL,
    'usingfy' => '1',
    'orderby' => 'week asc',
);