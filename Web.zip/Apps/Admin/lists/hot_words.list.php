<?php

return array(
    'model' => 'HotWords',
    'search' => NULL,
    'usesql' => '0',
    'sql' => '',
    'sqlargs' => NULL,
    'usingfy' => '1',
    'orderby' => 'sort asc',
);