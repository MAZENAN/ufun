<?php return array (
  'model' => 'tag',
  'search' => NULL,
  'usesql' => '0',
  'sql' => '',
  'sqlargs' => NULL,
  'usingfy' => '0',
  'orderby' => '',
);