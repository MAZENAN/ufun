<?php

class SellerController extends SmcmsController{

//    public function listData($select) {
//        return parent::listData($select);
//    }
}