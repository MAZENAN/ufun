<?php
return array (
  'model' => 'Comment',
  'search' => array(
    array(
      'name' => 'replay',
      'label' => '是否回复',
      'boxname' => 'replay',
      'type' => 'select',
      'schtp' => '9',
      'style' => '',
      'css' => '',
    )
  ),
  'usesql' => '0',
  'sql' => '',
  'sqlargs' => NULL,
  'usingfy' => '1',
  'orderby' => '',
);