<?php return array (
     'qqauth_appid' => '101234596',
    'qqauth_appkey' => '55f84316345030442b9a56b7c3f63491',
  //     'qqauth_appid' => '101323026',
   //   'qqauth_appkey' => 'a693abbf097eda342151455d132ec26d',
  'weibo_akey' => '4215080888',
  'weibo_skey' => 'c2e6222807da8009127d43bfbfac0b2f',
);